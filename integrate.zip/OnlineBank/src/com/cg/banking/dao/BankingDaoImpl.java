package com.cg.banking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import java.time.Month;
import java.util.ArrayList;

import com.cg.banking.bean.OnlineBean;
import com.cg.banking.bean.UserBean;
import com.cg.banking.dbUtil.dbUtil;






public class BankingDaoImpl implements IBankingDao {
	
	Connection conn=null;
	
	

	


	@Override
	public boolean checkLogin(UserBean bean) throws IOException, SQLException 
	{
		
		
		conn=dbUtil.getConnection();
		
		
		
		
		String sql="Select * from user_details where user_id=? and login_password=?";
		
		PreparedStatement pst=conn.prepareStatement(sql);
		
		pst.setInt(1,bean.getUserId());
		pst.setString(2,bean.getLoginPassword());
		
		ResultSet rs=pst.executeQuery();
		
		if(rs.next()==false)
		{
			return false;
		}
		else
		{		
			if(rs.getString(7).equals("N"))
			{
				return false;
			}
			else
			{
				return true;
			}
			
		}
		
		
		
		
	}





	@Override
	public ArrayList<UserBean> changePassword(UserBean bean) throws IOException, SQLException
	{
		ArrayList<UserBean> list=new ArrayList<UserBean>();
		conn=dbUtil.getConnection();
		String secretQuestionAnswer="null";
		String secretQuestion="null";

		String sql="Select * from user_details where user_id=?";
		
		PreparedStatement pst=conn.prepareStatement(sql);
		
		pst.setInt(1,bean.getUserId());
		
		
		ResultSet rs=pst.executeQuery();
		
		while(rs.next())
		{
			
			 
			secretQuestion =rs.getString(4);
			secretQuestionAnswer=rs.getString(5);
			
		}
		
		list.add(new UserBean(secretQuestion,secretQuestionAnswer));	
			
		return list;
			
	
	}





	@Override
	public int updatePassword(UserBean bean) throws SQLException, IOException 
	{
		conn=dbUtil.getConnection();
		String updateQuery="update user_details set login_password=? where user_id=?";
		
		
		
		PreparedStatement ps=conn.prepareStatement(updateQuery);
		
		if(bean.getLoginPassword()==null)
		{
			ps.setString(1,"sbq500#");
			
			ps.setInt(2,bean.getUserId());
		}
		else
		{
			ps.setString(1,bean.getLoginPassword());
			
			ps.setInt(2,bean.getUserId());
		}
		
		
		int result=ps.executeUpdate();
		return result;
	}





	@Override
	public int updateLock(UserBean bean) throws IOException, SQLException {
		
		conn=dbUtil.getConnection();
		String updateQuery="update user_details set lock_status=? where user_id=?";
		
		
		
		PreparedStatement ps=conn.prepareStatement(updateQuery);
		
		
	
			ps.setString(1,"N");
			
			ps.setInt(2,bean.getUserId());
		
		
		
		int lockResult=ps.executeUpdate();
		return lockResult;
		
		
		
	}





	@Override
	public ArrayList<UserBean> getAccountId(UserBean bean) throws IOException, SQLException {
		
		long accountId=0;
		
		ArrayList<UserBean> list=new ArrayList<UserBean>();
		conn=dbUtil.getConnection();
		

		String sql="Select * from user_details where user_id=?";
		
		PreparedStatement pst=conn.prepareStatement(sql);
		
		pst.setInt(1,bean.getUserId());
		
		
		ResultSet rs=pst.executeQuery();
		
		while(rs.next())
		{
			
			 
			 accountId=rs.getLong(1);
			
		}
		
		list.add(new UserBean(accountId));	
			
		return list;
	}
	
	
	@Override
	public ArrayList<OnlineBean> retriveDetails(int id, java.time.LocalDate startdate,java.time.LocalDate enddate) throws SQLException, IOException {
		
			System.out.println("Your id is "+id);
			int day = startdate.getDayOfMonth();
			Month month = startdate.getMonth();
			int year = startdate.getYear();
			String sDateToPass = day +"-"+month+"-"+ year;
			day = enddate.getDayOfMonth();
			month = enddate.getMonth();
			year = enddate.getYear();
			String eDateToPass = day +"-"+month+"-"+ year;
			//System.out.println(eDateToPass);
			Connection conn=dbUtil.getConnection();
			String sql="Select * from Transactions where account_no=? and DATE_OF_TRANSACTION >=? and DATE_OF_TRANSACTION <=?";
			ArrayList<OnlineBean> list=new ArrayList<OnlineBean>();
			PreparedStatement stmt=conn.prepareStatement(sql);
			stmt.setInt(1, id);
			stmt.setString(2, sDateToPass);
			stmt.setString(3, eDateToPass);
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				int tid=rs.getInt(1);
				String desc=rs.getString(2);
				Date dat=rs.getDate(3);
				String transType=rs.getString(4);
				int transAmount=rs.getInt(5);
				list.add(new OnlineBean(tid,desc,dat,transType,transAmount));
			}
			return list;
	}

	@Override
	public ArrayList<OnlineBean> retriveLast(int id) throws SQLException, IOException {
		Connection conn=dbUtil.getConnection();
		String sql="SELECT *  FROM (SELECT * FROM transactions ORDER  BY transaction_id DESC) WHERE ROWNUM <=3 and account_no=?";
		ArrayList<OnlineBean> list=new ArrayList<OnlineBean>();
		PreparedStatement stmt=conn.prepareStatement(sql);
		stmt.setInt(1, id);
		ResultSet rs=stmt.executeQuery();
		while(rs.next())
		{
			int tid=rs.getInt(1);
			String desc=rs.getString(2);
			Date dat=rs.getDate(3);
			String transType=rs.getString(4);
			int transAmount=rs.getInt(5);
			list.add(new OnlineBean(tid,desc,dat,transType,transAmount));
		}
		return list;
	}	
		
}
	
	


