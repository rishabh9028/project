package com.cg.banking.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.OnlineBean;


public interface IBankingDao {
	
	
	public boolean checkLogin(UserBean bean) throws IOException, SQLException;

	public ArrayList<UserBean> changePassword(UserBean bean) throws IOException, SQLException;
	
	public int updatePassword(UserBean bean) throws SQLException, IOException;
	
	public int updateLock(UserBean bean) throws IOException, SQLException;

	public ArrayList<UserBean> getAccountId(UserBean bean) throws IOException, SQLException;

//home
	
	ArrayList<OnlineBean> retriveDetails(int id, java.time.LocalDate startdate, java.time.LocalDate enddate) throws SQLException, IOException;

	ArrayList<OnlineBean> retriveLast(int id) throws SQLException, IOException;

}
