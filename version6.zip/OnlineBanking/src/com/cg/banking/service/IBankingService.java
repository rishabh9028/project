package com.cg.banking.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.UserBean1;

public interface IBankingService {

	int createNewAcc(UserBean ub) throws IOException, SQLException;

	ArrayList<UserBean1> reteriveDaily() throws IOException, SQLException;

	ArrayList<UserBean1> reteriveMonthly() throws IOException, SQLException;

	ArrayList<UserBean1> reteriveYearly() throws IOException, SQLException;

	ArrayList<UserBean1> reteriveQuaterly() throws IOException, SQLException;

	boolean validateName(String name);

	boolean validateBal(int accbal);

	boolean validatemob(long mobileno);

	boolean validateBal(String email);

	boolean validateName(int acctype);

	boolean validateName(String username, String password) throws IOException, SQLException;

	int updateAccBal(UserBean ub) throws IOException, SQLException;

	int updateName(UserBean ub) throws IOException, SQLException;

	int updateAddress(UserBean ub) throws IOException, SQLException;

	int updateEmail(UserBean ub) throws IOException, SQLException;

	int updateMobileno(UserBean ub) throws IOException, SQLException;

	int updatePancard(UserBean ub) throws IOException, SQLException;

	int deleteAcc(UserBean ub) throws IOException, SQLException;

	

}
