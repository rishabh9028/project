package com.cg.banking.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.UserBean1;

public interface IBankingDao {

	int createNewAcc(UserBean ub) throws IOException, SQLException;

	ArrayList<UserBean1> reteriveDaily() throws IOException, SQLException;

	ArrayList<UserBean1> reteriveMonthly() throws IOException, SQLException;

	ArrayList<UserBean1> reteriveYearly() throws IOException, SQLException;

	ArrayList<UserBean1> reteriveQuaterly() throws IOException, SQLException;

	int updateAccBal(UserBean ub) throws IOException, SQLException;

	int updateName(UserBean ub) throws IOException, SQLException;

	int updateAddress(UserBean ub) throws IOException, SQLException;

	int updateEmail(UserBean ub) throws IOException, SQLException;

	int updateMobileno(UserBean ub) throws IOException, SQLException;

	int updatePancard(UserBean ub) throws IOException, SQLException;

	int deleteAcc(UserBean ub) throws IOException, SQLException;


}
