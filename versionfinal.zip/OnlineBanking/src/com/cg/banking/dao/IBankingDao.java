package com.cg.banking.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.UserBean1;
import com.cg.banking.exception.OnlineBankingException;

public interface IBankingDao {

	int createNewAcc(UserBean ub) throws OnlineBankingException;

	ArrayList<UserBean1> reteriveDaily() throws IOException, SQLException, OnlineBankingException;

	ArrayList<UserBean1> reteriveMonthly() throws IOException, SQLException, OnlineBankingException;

	ArrayList<UserBean1> reteriveYearly() throws IOException, SQLException, OnlineBankingException;

	ArrayList<UserBean1> reteriveQuaterly() throws IOException, SQLException, OnlineBankingException;

	int updateAccBal(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updateName(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updateAddress(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updateEmail(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updateMobileno(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updatePancard(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int deleteAcc(UserBean ub) throws IOException, SQLException, OnlineBankingException;


}
