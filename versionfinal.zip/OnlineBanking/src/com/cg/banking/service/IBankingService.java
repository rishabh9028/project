package com.cg.banking.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.UserBean1;
import com.cg.banking.exception.OnlineBankingException;

public interface IBankingService {

	int createNewAcc(UserBean ub) throws OnlineBankingException;

	ArrayList<UserBean1> reteriveDaily() throws IOException, SQLException, OnlineBankingException;

	ArrayList<UserBean1> reteriveMonthly() throws IOException, SQLException, OnlineBankingException;

	ArrayList<UserBean1> reteriveYearly() throws IOException, SQLException, OnlineBankingException;

	ArrayList<UserBean1> reteriveQuaterly() throws IOException, SQLException, OnlineBankingException;

	boolean validateName(String name);

	boolean validateBal(int accbal);

	boolean validatemob(String mobileno);

	

	

	boolean validateAdmin(String password) throws IOException, SQLException;

	int updateAccBal(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updateName(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updateAddress(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updateEmail(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updateMobileno(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int updatePancard(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	int deleteAcc(UserBean ub) throws IOException, SQLException, OnlineBankingException;

	boolean validateId(int accid) throws IOException, SQLException;

	boolean validateEmail(String email);

	boolean validateacctype(int acctype);

	boolean validateAddress(String address);



	

}
