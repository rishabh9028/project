package com.cg.banking.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.UserBean1;
import com.cg.banking.exception.OnlineBankingException;
import com.cg.banking.service.BankingServiceImpl;
import com.cg.banking.service.IBankingService;





public class BankingUi {
	
	public static void main(String[] args) throws IOException, SQLException, ParseException, OnlineBankingException {
		BankingUi operation = new BankingUi();
		
	
	Scanner sc = new Scanner(System.in);
	
		
	IBankingService service=new BankingServiceImpl();
		
		
		
		while(true){
		System.out.println(" -----------");
		System.out.println("|ADMIN LOGIN|");
		System.out.println(" -----------");
		System.out.println("Admin:Rishabh");
		System.out.println("Enter password");
		String password=sc.next();
		
		if(service.validateAdmin(password))
		{
		
		
			while(true){
			System.out.println("***************");
			System.out.println(" --------------");
			System.out.println("|ADMIN FUNCTIONS|");
			System.out.println(" --------------");
			System.out.println("***************");
			System.out.println("Enter Your Choice");
			
			System.out.println("\n1.Create New Account\n2.Retrive Transcations\n3.Update Account\n4.Delete Account\n5.Exit");
			int ch = sc.nextInt();
			switch(ch){
			case 1:
				operation.createNewAcc();
				break;
			case 2:
				operation.reteriveTrans();
				break;
			case 3:
				operation.updateAcc();
				break;
			case 4:
				operation.deleteAcc();
			case 5:
				System.exit(0);
			}}
		}}
		
		 
}


	
	private void deleteAcc() throws IOException, SQLException, ParseException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		{
		IBankingService service=new BankingServiceImpl();
		BankingUi operation = new BankingUi();
		System.out.println("enter the account no you want to delete");
		int accid=sc.nextInt();
		if(service.validateId(accid))
		{
			UserBean ub = new UserBean();
			ub.setAccid(accid);
			int res=service.deleteAcc(ub);
		
			System.out.println("deleted");
	
		
				
		
		}
		
		}
	}

	private void updateAcc() throws IOException, SQLException, ParseException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		BankingUi operation = new BankingUi();
	
		System.out.println("**********************");
		System.out.println(" ----------------");
		System.out.println("|UPDATION DETAILS|");
		System.out.println(" ----------------");
		System.out.println("**********************");
		System.out.println("\n1.Update Account Balance\n2.Update Name\n3.Update Email\n4.Update Address\n5.Update Pancard\n6.Update MobileNo\n7.Exit");
		int ch1= sc.nextInt();
		switch(ch1){
		case 1:
			updateAccBal();
			break;
		case 2:
			updateName();
			break;
		case 3:
			updateEmail();
			break;
		case 4:
			updateAddress();
			break;
		case 5:
			updatePancard();
		case 6:
			updateMobileno();
		case 7:
			System.exit(0);
		}
		
		
		
	}

	private void updateMobileno() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		IBankingService service=new BankingServiceImpl();
		System.out.println("Enter the Acc id u want to update");
		int accid=sc.nextInt();
		if(service.validateId(accid))
		{
		
		System.out.println("Enter MobileNo");
		String mobileno =sc.next();
		UserBean ub = new UserBean();
		ub.setAccid(accid);
		ub.setMobileno(mobileno);
		int res=service.updateMobileno(ub);
		System.out.println("updated");
	
	}
	}
	private void updatePancard() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		IBankingService service=new BankingServiceImpl();
		System.out.println("Enter the Acc id u want to update");
		int accid=sc.nextInt();
		if(service.validateId(accid))
		{
		
		System.out.println("Enter Pancard no");
		String pancard=sc.next();
		UserBean ub = new UserBean();
		ub.setAccid(accid);
		ub.setPancard(pancard);
		int res=service.updatePancard(ub);
		System.out.println("updated");	
	
	}}
	private void updateAddress() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		IBankingService service=new BankingServiceImpl();
		System.out.println("Enter the Acc id u want to update");
		int accid=sc.nextInt();
		if(service.validateId(accid))
		{
		
		System.out.println("Enter Address");
		String address=sc.next();
		UserBean ub = new UserBean();
		ub.setAccid(accid);
		ub.setAddress(address);
		int res=service.updateAddress(ub);
		System.out.println("updated");
		}
	}
	private void updateEmail() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		IBankingService service=new BankingServiceImpl();
		System.out.println("Enter the Acc id u want to update");
		int accid=sc.nextInt();
		if(service.validateId(accid))
		{
		
		System.out.println("Enter Email");
		String email=sc.next();
		UserBean ub = new UserBean();
		ub.setAccid(accid);
		ub.setEmail(email);
		int res=service.updateEmail(ub);
		System.out.println("updated");
	}
	}
	private void updateName() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		IBankingService service=new BankingServiceImpl();
		System.out.println("Enter the Acc id u want to update");
		int accid=sc.nextInt();
		if(service.validateId(accid))
		{
		
		System.out.println("Enter name");
		String name=sc.next();
		UserBean ub = new UserBean();
		ub.setAccid(accid);
		ub.setName(name);
		int res=service.updateName(ub);
		System.out.println("updated");
		
	}
	}
	private void updateAccBal() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		IBankingService service=new BankingServiceImpl();
		System.out.println("Enter the Acc id u want to update");
		int accid=sc.nextInt();
		if(service.validateId(accid))
		{
		
		System.out.println("Enter account balance");
		int accbal=sc.nextInt();
		UserBean ub = new UserBean();
		ub.setAccid(accid);
		ub.setAccbal(accbal);
		int res=service.updateAccBal(ub);
		System.out.println("updated");
		}}
	

	private void reteriveTrans() throws IOException, SQLException, ParseException, OnlineBankingException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		BankingUi operation = new BankingUi();

		System.out.println("**********************");
		System.out.println(" -------------------");
		System.out.println("|TRANSACTION DETAILS|");
		System.out.println(" -------------------");
		System.out.println("**********************");
		System.out.println("\n1.Daily Trans\n2.Monthly Trans\n3.Quaterly Trans\n4.Yearly Trans\n5.Exit");
		int ch1= sc.nextInt();
		switch(ch1){
		case 1:
			reteriveDaily();
			break;
		case 2:
			reteriveMonthly();
			break;
		case 3:
			reteriveQuaterly();
			break;
		case 4:
			reteriveYearly();
			break;
		case 5:
			System.exit(0);
		}
	
	}
	private void reteriveQuaterly() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		IBankingService service=new BankingServiceImpl();
		System.out.println("These are the quaterly details");
		System.out.println("\nTransaction_ID\tTran_description\tDateofTransaction\tTransactionType\tTranAmount\tAccount_No");
		ArrayList<UserBean1> al=service.reteriveQuaterly();
		for(UserBean1 ub1:al){
			System.out.print(ub1.getTransactionID()+"\t\t\t");	
			System.out.print(ub1.getTrandescription()+"\t\t");
			System.out.print(ub1.getDateofTransaction()+"\t\t");
			System.out.print(ub1.getTransactionType()+"\t\t");
			System.out.print(ub1.getTranAmount()+"\t\t");
			System.out.println(ub1.getAccountNo());
			
		}
		
	}
	private void reteriveYearly() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		IBankingService service=new BankingServiceImpl();
		System.out.println("These are the yearly details");
		System.out.println("\nTransaction_ID\tTran_description\tDateofTransaction\tTransactionType\tTranAmount\tAccount_No");

		ArrayList<UserBean1> al=service.reteriveYearly();
		for(UserBean1 ub1:al){
			System.out.print(ub1.getTransactionID()+"\t\t\t");	
			System.out.print(ub1.getTrandescription()+"\t\t");
			System.out.print(ub1.getDateofTransaction()+"\t\t");
			System.out.print(ub1.getTransactionType()+"\t\t");
			System.out.print(ub1.getTranAmount()+"\t\t");
			System.out.println(ub1.getAccountNo());
				
		}
		
	}
	private void reteriveMonthly() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		IBankingService service=new BankingServiceImpl();
		System.out.println("These are the monthly details");
		System.out.println("\nTransaction_ID\tTran_description\tDateofTransaction\tTransactionType\tTranAmount\tAccount_No");
		ArrayList<UserBean1> al=service.reteriveMonthly();
		for(UserBean1 ub1:al){
			System.out.print(ub1.getTransactionID()+"\t\t\t");	
			System.out.print(ub1.getTrandescription()+"\t\t");
			System.out.print(ub1.getDateofTransaction()+"\t\t");
			System.out.print(ub1.getTransactionType()+"\t\t");
			System.out.print(ub1.getTranAmount()+"\t\t");
			System.out.println(ub1.getAccountNo());	
		}
		
		
	}
	private void reteriveDaily() throws IOException, SQLException, OnlineBankingException {
		IBankingService service=new BankingServiceImpl();
		System.out.println("These are the daily details");
		System.out.println("\nTransaction_ID\tTran_description\tDateofTransaction\tTransactionType\tTranAmount\tAccount_No");
		ArrayList<UserBean1> al=service.reteriveDaily();
		for(UserBean1 ub1:al){
			System.out.print(ub1.getTransactionID()+"\t\t\t");	
			System.out.print(ub1.getTrandescription()+"\t\t");
			System.out.print(ub1.getDateofTransaction()+"\t\t");
			System.out.print(ub1.getTransactionType()+"\t\t");
			System.out.print(ub1.getTranAmount()+"\t\t");
			System.out.println(ub1.getAccountNo());		
		}
		
	}
	private void createNewAcc() throws  IOException, SQLException,ParseException, OnlineBankingException {
		// TODO Auto-generated method stub
		try{
		IBankingService service=new BankingServiceImpl();
		Scanner sc = new Scanner(System.in);
		  
		System.out.println("Enter Account Type:1.Savings 2.Current");
		int acctype=sc.nextInt();
		if(service.validateacctype(acctype))
		{
		System.out.println("Enter Account Balance:");
		int accbal=sc.nextInt();
		if(service.validateBal(accbal))
		{
		System.out.println(" Open Date is :");
	    System.out.println( new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()) );

		//Date od=Date.valueOf(odate);
		System.out.println("Enter name:");
		String name=sc.next();
		name+=sc.nextLine();
		if(service.validateName(name))
		{
		System.out.println("Enter Email :");
		String email=sc.next();
		if(service.validateEmail(email))
		{
		System.out.println("Enter Address:");
		String address=sc.next();
		address+=sc.nextLine();
		if(service.validateAddress(address))
		{
		System.out.println("Enter pancard number");
		String pancard=sc.next();
		System.out.println("Enter Mobile Number :");
		String mobileno=sc.next();
		if(service.validatemob(mobileno))
		{
		
		UserBean ub = new UserBean(acctype,accbal,name,email,address,pancard,mobileno);
		int res=service.createNewAcc(ub);
		System.out.println("inserted");
		
		}}}}}}}
		catch(OnlineBankingException e)
		{
			throw new OnlineBankingException("Exception occured"+e.getMessage());
		}
		catch(InputMismatchException f)
		{
			throw new OnlineBankingException("Please enter valid Details"+f.getMessage());
		}
		
		
		
	
	}}
